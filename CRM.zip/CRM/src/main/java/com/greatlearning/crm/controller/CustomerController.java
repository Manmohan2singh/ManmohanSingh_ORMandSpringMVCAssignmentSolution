package com.greatlearning.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.crm.entity.Customer;
import com.greatlearning.crm.service.CustomerService;

@Controller
@RequestMapping("/Customer")
public class CustomerController {

	@Autowired
	private CustomerService customerservice;

	// add mapping for "/list"
	@RequestMapping("/list")
	public String listCustomers(Model theModel) {

		// get Customer from db
		List<Customer> theCustomer = customerservice.findAll();
		// add to the spring model
		theModel.addAttribute("Customer", theCustomer);

		return "list-customers";
	}

	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {

		// create model attribute to bind form data
		Customer theCustomer = new Customer();

		theModel.addAttribute("Customer", theCustomer);

		return "customer-form";
	}

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("customerId") int theId, Model theModel) {

		// get the Customer from the service
		Customer theCustomer = customerservice.findById(theId);

		// set Customer as a model attribute to pre-populate the form
		theModel.addAttribute("Customer", theCustomer);

		// send over to our form
		return "customer-form";
	}

	@PostMapping("/save")
	public String saveCustomer(@RequestParam("id") int id, @RequestParam("fname") String fname,
			@RequestParam("lname") String lname, @RequestParam("email") String email) {

		System.out.println(id);

		Customer theCustomer;
		if (id != 0) {
			theCustomer = customerservice.findById(id);
			theCustomer.setFname(fname);
			theCustomer.setLname(lname);
			theCustomer.setEmail(email);
		} else
			theCustomer = new Customer(fname, lname, email);
		// save the Customer
		customerservice.save(theCustomer);

		// use a redirect to prevent duplicate submissions
		return "redirect:/Customer/list";

	}

	@RequestMapping("/delete")
	public String delete(@RequestParam("customerId") int theId) {

		// delete the Customer
		customerservice.deleteById(theId);

		// redirect to /Customer/list
		return "redirect:/Customer/list";

	}

}
