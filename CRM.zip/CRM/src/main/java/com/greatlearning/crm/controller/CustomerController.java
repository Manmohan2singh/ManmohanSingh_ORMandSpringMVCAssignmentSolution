package com.greatlearning.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.crm.entity.Customer;
import com.greatlearning.crm.service.CustomerService;



@Controller
@RequestMapping("/Customer")
public class CustomerController {

	@Autowired
	private CustomerService customerservice;



	// add mapping for "/list"
	@RequestMapping("/list")
	public String listBooks(Model theModel) {

		// get Customer from db
		List<Customer> theCustomer = customerservice.findAll();

		// add to the spring model
		theModel.addAttribute("Customer", theCustomer);

		return "list-customers";
	}

	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {

		// create model attribute to bind form data
		Customer theCustomer = new Customer();

		theModel.addAttribute("Customer", theCustomer);

		return "customer-form";
	}

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("id") int theId,
			Model theModel) {

		// get the Customer from the service
		Customer theCustomer = customerservice.findById(theId);


		// set Customer as a model attribute to pre-populate the form
		theModel.addAttribute("Customer", theCustomer);

		// send over to our form
		return "customer-form";			
	}


	@PostMapping("/save")
	public String saveCustomer(@RequestParam("id") int id,
			@RequestParam("fname") String fname,@RequestParam("lname") String lname,@RequestParam("email") String email) {

		System.out.println(id);

		Customer theCustomer;
		if(id!=0)
		{
			theCustomer=customerservice.findById(id);
			theCustomer.setName(fname);
			theCustomer.setCategory(lname);
			theCustomer.setAuthor(email);
		}
		else
			theCustomer=new Customer(fname, lname, email);
		// save the Customer
		customerservice.save(theCustomer);


		// use a redirect to prevent duplicate submissions
		return "redirect:/Customer/list";

	}


	@RequestMapping("/delete")
	public String delete(@RequestParam("id") int theId) {

		// delete the Customer
		customerservice.deleteById(theId);

		// redirect to /Customer/list
		return "redirect:/Customer/list";

	}


	@RequestMapping("/search")
	public String search(@RequestParam("fname") String fname,
			@RequestParam("email") String email,
			Model theModel) {

		// check names, if both are empty then just give list of all Customers
		if (fname.trim().isEmpty() && email.trim().isEmpty()) {
			return "redirect:/Customer/list";
		}
		else {
			// else, search by first name and last name
			List<Customer> theCustomer =
					customerservice.searchBy(fname, email);

			// add to the spring model
			theModel.addAttribute("Customer", theCustomer);

			// send to list-Customers
			return "list-customers";
		}

	}
}


















