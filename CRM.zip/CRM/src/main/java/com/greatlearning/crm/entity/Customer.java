package com.greatlearning.crm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Customer")
public class Customer {

	// define fields

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;


	@Column(name="fname")
	private String fname;


	@Column(name="lname")
	private String lname;


	@Column(name="email")
	private String email;


	// define constructors

	public Customer()
	{

	}

	public Customer(String fname, String lname, String email) {
		super();

		this.fname = fname;
		this.lname = lname;
		this.email = email;
	}

	// define getter/setter

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return fname;
	}

	public void setName(String fname) {
		this.fname = fname;
	}

	public String getCategory() {
		return lname;
	}

	public void setCategory(String lname) {
		this.lname = lname;
	}

	public String getAuthor() {
		return email;
	}

	public void setAuthor(String email) {
		this.email = email;
	}

	// define tostring
	@Override
	public String toString() {
		return "Customer [id=" + id + ", fname=" + fname + ", lname=" + lname + ", email=" +email + "]";
	}

}











